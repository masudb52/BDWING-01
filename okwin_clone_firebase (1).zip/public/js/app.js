
document.getElementById('app').innerHTML = '<p>Loading Game...</p>';
